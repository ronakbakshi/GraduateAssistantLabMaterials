/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package professors;

import java.util.Scanner;

/**
 *
 * @author instructor
 */
public class ProfessorDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // created the professor object with 4 argument constructor
        Professor profObject01 = new Professor("Michael", "Downey", 50988, "6602240486", "9277 Fairway Drive, Apt#208, Des Plaines, IL");
        System.out.println("Professor Details01");
        System.out.println("Professor ID: " + profObject01.getProfessorID());
        System.out.println("Name: " + profObject01.getFirstName() + " " + profObject01.getLastName());
        System.out.println("Address: " + profObject01.getAddress());
        System.out.println("Contact Number: " + profObject01.getPhoneNumber());
        System.out.println("**************************************************\n");
        // created the professor object with no-argument constructor
        Professor profObject02 = new Professor();
        System.out.println("Professor Details02");
        System.out.println("Professor ID: " + profObject02.getProfessorID());
        System.out.println("Name: " + profObject02.getFirstName() + " " + profObject02.getLastName());
        System.out.println("Address: " + profObject02.getAddress());
        System.out.println("Contact Number: " + profObject02.getPhoneNumber());
        System.out.println("**************************************************\n");
        // now set the value of attributes for the profObject02
        profObject02.setProfessorID(12354);
        profObject02.setFirstName("Julie");
        profObject02.setLastName("Clark");
        profObject02.setPhoneNumber("9494949494");
        profObject02.setAddress("1231 University Drive, Apt#60, Kansas, MO");
        System.out.println("Testing toString() method of Professor class:\n" + profObject02.toString());
        
        System.out.println("**************************************************\n");
        
        System.out.println("Testing the ProfessorSalary class:");
        Scanner scObj = new Scanner(System.in);
        System.out.print("Enter the hourly pay rate of the Professor: $");
        double payRate=scObj.nextDouble();
        System.out.print("Enter the insurance rate of the Professor in percentage: ");
        double insuranceRate=scObj.nextDouble();
        System.out.print("Enter the tax rate of the Professor in percentage: ");
        double taxRate=scObj.nextDouble();
        System.out.print("Enter the bonus amount: $");
        double bonus=scObj.nextDouble();
        
        ProfessorSalary professorSalaryObj1 = new ProfessorSalary(payRate,bonus,insuranceRate,taxRate);
        System.out.println("**************************************************\n");
        System.out.println("Testing the toString() method of ProfessorSalary class:\n"+professorSalaryObj1.toString());
        System.out.println("The monthly salary of the Professor is: $"+professorSalaryObj1.monthlySalary());
        System.out.println("The monthly insurance of the Professor is: $"+professorSalaryObj1.monthlyInsurance());
        System.out.println("The annual gross salary of the Professor is: $"+professorSalaryObj1.annualGrossSalary());
        System.out.println("The gross annual net pay of the Professor is: "+professorSalaryObj1.annualNetPay());
        System.out.println("**************************************************\n");
        
        System.out.println("The details of professorSalaryObj2 are as follows:");
        ProfessorSalary professorSalaryObj2 = new ProfessorSalary();
        System.out.println("Testing the toString() method of ProfessorSalary class:\n"+professorSalaryObj2.toString());
        System.out.println("The monthly salary of the Professor is: $"+professorSalaryObj2.monthlySalary());
        System.out.println("The monthly insurance of the Professor is: $"+professorSalaryObj2.monthlyInsurance());
        System.out.println("The annual gross salary of the Professor is: $"+professorSalaryObj2.annualGrossSalary());
        System.out.println("The gross annual net pay of the Professor is: "+professorSalaryObj2.annualNetPay());
        
        professorSalaryObj2.setHourlyRate(42.85);
        professorSalaryObj2.setInsuranceRate(15.30);
        professorSalaryObj2.setTaxRate(11.55);
        professorSalaryObj2.setBonus(6344.66);
        System.out.println("**************************************************\n");
        System.out.println("Testing the toString() method of ProfessorSalary class:"+professorSalaryObj2.toString());
        System.out.println("The monthly salary of the Professor is: $"+professorSalaryObj2.monthlySalary());
        System.out.println("The monthly insurance of the Professor is: $"+professorSalaryObj2.monthlyInsurance());
        System.out.println("The annual gross salary of the Professor is: $"+professorSalaryObj2.annualGrossSalary());
        System.out.println("The gross annual net pay of the Professor is: "+professorSalaryObj2.annualNetPay());           
    }
}
