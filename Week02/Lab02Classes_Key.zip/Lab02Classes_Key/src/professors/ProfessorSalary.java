/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package professors;

/**
 * Contains details about Professor Salary
 * @author instructor
 */
public class ProfessorSalary {
    private double hourlyRate;
    private double bonus;
    private double insuranceRate;
    private double taxRate;
    private final int HOURS=40;
    /**
     * 4-Argument constructor to instantiate all the private variables
     * @param hourlyRate a double containing the hourly pay rate of the professor
     * @param bonus a double containing the annual bonus of the professor
     * @param insuranceRate a double containing the insurance rate of the professor
     * @param taxRate a double containing the tax rate rate of the professor
     */
    public ProfessorSalary(double hourlyRate, double bonus, double insuranceRate, double taxRate) {
        this.hourlyRate = hourlyRate;
        this.bonus = bonus;
        this.insuranceRate = insuranceRate;
        this.taxRate = taxRate;
    }
    /**
     * No argument constructor
     */
    public ProfessorSalary() {
    }
    /**
     * Returns the hourly pay rate of the professor
     * @return a double
     */
    public double getHourlyRate() {
        return hourlyRate;
    }
    /**
     * Sets the hourly pay rate of the professor
     * @param hourlyRate a double which contains the hourly rate of the professor
     */
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }
    /**
     * Returns the bonus amount per annum for a professor
     * @return a double
     */
    public double getBonus() {
        return bonus;
    }
    /**
     * Sets the bonus amount per annum for a professor
     * @param bonus contains the bonus amount per annum for a professor
     */
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    /**
     * Returns the insurance rate for the professor
     * @return a double
     */
    public double getInsuranceRate() {
        return insuranceRate;
    }
    /**
     * Sets insurance rate for the professor
     * @param insuranceRate a double containing the insurance rate of the professor
     */
    public void setInsuranceRate(double insuranceRate) {
        this.insuranceRate = insuranceRate;
    }
    /**
     * Returns the tax rate of the professor
     * @return a double
     */
    public double getTaxRate() {
        return taxRate;
    }
    /**
     * Sets tax rate of the professor
     * @param taxRate is the tax rate of professor in percentage
     */
    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }
    /**
     * Calculates and returns the monthly salary of the professor
     * @return a double
     */
    public double monthlySalary(){
        return 4*HOURS*hourlyRate;
    }
    /**
     * calculates and returns the monthly insurance for the professor
     * @return a double
     */
    public double monthlyInsurance(){
        return 4*hourlyRate*HOURS*insuranceRate/100;
        
    }
    /**
     * Calculates and returns the annual gross salary of the professor
     * @return a double
     */
    public double annualGrossSalary(){
        return 12*(monthlySalary())+bonus;
    }
    /**
     * calculates and returns the annual net pay of the professor
     * @return a double
     */
    public double annualNetPay(){
        return (annualGrossSalary()*(1-0.0925))-(12*monthlyInsurance());
    }
    /**
     * Returns the details of Professor salary
     * @return a String
     */
    @Override
    public String toString() {
        return "Hourly pay rate: $" + hourlyRate + ", insurance rate: " + insuranceRate + "%, tax: " + taxRate +  "%, annual bonus: $" + bonus+ ", Hours per week: " + HOURS;
    }   
}