/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package professors;

/**
 * Class containing details about Professor
 * @author instructor
 */
public class Professor {
    private String firstName;
    private String lastName;
    private int professorID;
    private String phoneNumber;
    private String address;
    
    /**
     * 5-Argument constructor to initialize all the variables
     * @param firstName
     * @param lastName
     * @param professorID
     * @param phoneNumber
     * @param address 
     */
    public Professor(String firstName, String lastName, int professorID, String phoneNumber, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.professorID = professorID;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }
    /**
     * No-Argument constructor, it does nothing
     */
    public Professor() {
    }
    /**
     * Returns the first name of the professor
     * @return a String 
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * Sets the firstName of the professor
     * @param firstName a String containing the first name of the professor
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /**
     * Returns the last name of the professir
     * @return a String
     */
    public String getLastName() {
        return lastName;
    }
    /**
     * Sets the last name of the professor
     * @param lastName a String containing the last name of the professor
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    /**
     * Returns the professor's ID
     * @return an Integer
     */
    public int getProfessorID() {
        return professorID;
    }
    /**
     * Sets the professor ID
     * @param professorID an Integer used to set the professor ID
     */
    public void setProfessorID(int professorID) {
        this.professorID = professorID;
    }
    /**
     * Returns phone number of the professor
     * @return a String
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }
    /**
     * Sets the phone number of the professor
     * @param phoneNumber a String which contains the phone number of the professor
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    /**
     * Returns address of the professor
     * @return a String 
     */
    public String getAddress() {
        return address;
    }
    /**
     * Sets the address of professor
     * @param address a String containing the address of professor
     */
    public void setAddress(String address) {
        this.address = address;
    }
    /**
     * Returns the details of professor
     * @return a String
     */
    @Override
    public String toString() {
        return firstName + " " + lastName + "with professorID:" + professorID + ", phone number: " + phoneNumber + " and address: " + address;
    }
}
