/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

import java.util.Random;

/**
 *
 * @author Instructor
 */
public class StringsAndNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String string1="   Welcome";
        String string2="   to  ";
        String string3="Computer";
        String string4=" Science     ";
        String string5=" and ";
        String string6="  Information    ";
        String string7="System   ";
        
        String string8=string1+string2+string3+string4+string5+string6+string7;
        System.out.println("The length of the concatenated string is:" + string8.length());
        String string9=string4.trim();
        System.out.println("Length of the trimmed string is:" + string9.length());
        System.out.println("Index of first e in science is:" + string8.substring(string8.indexOf("Science"),string8.indexOf("Science")+7).indexOf('e'));
        
        String word="rnururrunngisnnurun";
        System.out.println("First occurrence of word run is:" + word.indexOf("run"));
        String word1=word.substring(word.indexOf("run"), word.indexOf("run")+3);
        String word2=word.substring(word.indexOf("is"), word.indexOf("is")+2);
        System.out.println(word1.concat(word2).concat("fun"));
        
        int myValue1=4;
        int myValue2=6;
        System.out.println(Math.pow(myValue1, myValue2));
        
        double myNumber=26.30;
        System.out.println("Square root of the number is:" + Math.sqrt(myNumber));
        System.out.println("Ceil Value is:" +Math.ceil(myNumber));
        System.out.println("Floor Value is:" +Math.floor(myNumber));
        
        
        double myNumber1=30;
        double myNumber2=75;
        
        System.out.println(Math.round(Math.sin(myNumber1)));
        System.out.println(Math.round(Math.sin(myNumber2)));
        System.out.println(Math.round(Math.tan(myNumber1)));
        System.out.println(Math.round(Math.tan(myNumber2)));
        System.out.println(Math.ceil(Math.sinh(Math.sqrt(Math.pow(5, 2)+(4*3*3)+2)/(3*2))));
        
        Random randomObj = new Random();
        randomObj.setSeed(10l);
        System.out.println("\nFirst Random value:"+randomObj.nextInt(200));
        System.out.println("Second Random value:"+randomObj.nextInt(200));
        System.out.println("Third Random value:"+randomObj.nextInt(200));
        System.out.println("Fourth Random value:"+randomObj.nextInt(200));
        System.out.println("Fifth Random value:"+randomObj.nextInt(200));
        System.out.println("Sixth Random value:"+randomObj.nextInt(200));
        System.out.println("Seventh Random value:"+randomObj.nextInt(200));
        
        System.out.println("\nYes, I get the same values");
        
        Random randomObj1 = new Random();
        //randomObj.setSeed(10l);
        System.out.println("\nFirst Random value:"+randomObj1.nextInt(200));
        System.out.println("Second Random value:"+randomObj1.nextInt(200));
        System.out.println("Third Random value:"+randomObj1.nextInt(200));
        System.out.println("Fourth Random value:"+randomObj1.nextInt(200));
        System.out.println("Fifth Random value:"+randomObj1.nextInt(200));
        System.out.println("Sixth Random value:"+randomObj1.nextInt(200));
        System.out.println("Seventh Random value:"+randomObj1.nextInt(200));
        
        System.out.println("\nNo, I get different values");
        
        System.out.println("\nThe difference is because of setting a seed value and not setting the seed value");

                
    }
    
}
