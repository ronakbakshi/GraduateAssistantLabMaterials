/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzaorder;

/**
 *
 * @author Instructor
 */
public class PizzaOrder {

    private String name;
    private String address;
    private String contactNumber;
    private char size;
    private final double BASIC_CRUST_COST = 4.0;
    private final double BASIC_CHEESE_COST = 2.0;
    private final double BASIC_SAUCE_COST = 0.50;
    private final double DELIVERY_CHARGE = 2.75;
    private String toppings;
    /**
     * Constructor with multiple arguments
     * @param name
     * @param address
     * @param contactNumber
     * @param size
     * @param toppings 
     */
    public PizzaOrder(String name, String address, String contactNumber, char size, String toppings) {
        this.name = name;
        this.address = address;
        this.contactNumber = contactNumber;
        this.size = size;
        this.toppings = toppings;
    }
    /**
     * Returns the delivery charge for an order
     * @return a double
     */
    public double getDELIVERY_CHARGE() {
        return DELIVERY_CHARGE;
    }
    /**
     * Returns the toppings ordered
     * @return a String
     */
    public String getToppings() {
        return toppings;
    }
    /**
     * Returns the name on the order
     * @return a String
     */
    public String getName() {
        return name;
    }
    /**
     * Returns the address of the order
     * @return a String
     */
    public String getAddress() {
        return address;
    }
    /**
     * Returns the contact number on the order
     * @return a String
     */
    public String getContactNumber() {
        return contactNumber;
    }
    /**
     * Returns the size of the pizza
     * @return a character(S/M/L)
     */
    public char getSize() {
        return size;
    }
    /**
     * Extracts and returns the number of toppings
     * @return an int
     */
    public int getNumberOfToppings() {
        int numberOfToppings = 0;
        if (getToppings().isEmpty()) {
            return numberOfToppings;
        } else {
            numberOfToppings = 1;
            for (int i = 0; i < toppings.length(); i++) {
                if (toppings.charAt(i) == ',') {
                    numberOfToppings++;
                }
            }
            return numberOfToppings;
        }
    }
    /**
     * Returns the cost of the crust based on the size of the pizza selected
     * @return a double
     */
    public double getFinalCrustCost() {
        double finalCrustCost;
        switch (size) {
            case 'S':
                finalCrustCost = BASIC_CRUST_COST;
                break;
            case 'M':
                finalCrustCost = BASIC_CRUST_COST * (1 + 0.30);
                break;
            default:
                finalCrustCost = BASIC_CRUST_COST * (1 + 0.60);
                break;
        }
        return finalCrustCost;
    }
    /**
     * Returns the cost of the cheese based on the size of the pizza
     * @return a double
     */
    public double getFinalCheeseCost() {
        double finalCheeseCost;
        if (size == 'S') {
            finalCheeseCost = BASIC_CHEESE_COST;
        } else if (size == 'M') {
            finalCheeseCost = BASIC_CHEESE_COST * (1 + 0.40);
        } else {
            finalCheeseCost = BASIC_CHEESE_COST * (1 + 0.80);
        }
        return finalCheeseCost;
    }
    /**
     * Returns the cost of the toppings
     * @return a double
     */
    public double getToppingsCost() {
        double finalToppingsCost;
        int noOfToppings = getNumberOfToppings();
        if (size == 'S') {
            finalToppingsCost = noOfToppings * 1.5;
        } else if (size == 'M') {
            finalToppingsCost = noOfToppings * 2.0;
        } else {
            finalToppingsCost = noOfToppings * 2.5;
        }
        return finalToppingsCost;
    }
    /**
     * Returns the final price of the order
     * @param deliveryOption a character type
     * @return 
     */
    public double getFinalPrice(char deliveryOption) {
        double finalPrice = 0;
        if (deliveryOption == 'D') {
            finalPrice = getFinalCrustCost() + getFinalCheeseCost() + getToppingsCost() + BASIC_SAUCE_COST + DELIVERY_CHARGE;
        }else{
            finalPrice = getFinalCrustCost() + getFinalCheeseCost() + getToppingsCost() + BASIC_SAUCE_COST;
        }
        return finalPrice;
    }
    /**
     * Returns a String as specified in the sample output.
     * @return a String
     */
    @Override
    public String toString() {
        return "Order Name: " + name + "\nAddress: " + address + "\nContact Number: " + contactNumber + "\nPizza size: " + size  +"\nNumber of toppings: "+ getNumberOfToppings()  +  "\nCrust cost: $"+getFinalCrustCost() + "\nSauce cost: $" + BASIC_SAUCE_COST + "\nCheese cost: $"+ getFinalCheeseCost()+"\nToppings cost: $"+getToppingsCost();
    }
}
