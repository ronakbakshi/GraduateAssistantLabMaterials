/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzaorder;

import java.util.Scanner;

/**
 *
 * @author Instructor
 */
public class PizzaOrderDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Welcome to Northwest Pizza!");
        char choice = 0;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.print("Please enter a name for order: ");
            String name = sc.nextLine();
            System.out.print("Please choose Delivery(D) or Pick up(P): ");
            char ch = sc.nextLine().charAt(0);
            String address = "Not given";
            if (ch == 'D') {
                System.out.print("Please enter your address: ");
                address = sc.nextLine();
            }
            System.out.print("Please enter your contact number: ");
            String phoneNumber = sc.nextLine();
            System.out.print("Please choose the size of pizza(S/M/L): ");
            char size = sc.nextLine().charAt(0);
            System.out.print("Please enter the toppings you want to add separated by a comma: ");
            String toppings = sc.nextLine();
            System.out.println("****************************************************");
            System.out.println("Please review your order below: ");
            PizzaOrder pizza = new PizzaOrder(name, address, phoneNumber, size, toppings);
            System.out.println(pizza.toString());
            if (ch == 'D') {
                System.out.println("\nDelivery charges: $" + pizza.getDELIVERY_CHARGE());
            }
            System.out.println("****************************************************");
            System.out.println("Total bill amount to be paid: $" + pizza.getFinalPrice(ch));
            System.out.println("****************************************************");
            System.out.println("Do you wish to place another order?(Y/N): ");
            choice=sc.nextLine().charAt(0);
        }while(choice=='Y'||choice=='y');
        System.out.println("Thank you for your order!");
    }
}